# Todo TUI

An application for making a todo list for your projects in your terminal
